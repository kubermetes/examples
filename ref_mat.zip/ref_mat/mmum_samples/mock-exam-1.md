[1] w6,d3, complete
[]
[]
[]
[]
[]
[]
[]



============================================================================================================
[1]
Deploy a pod named nginx-pod using the nginx:alpine image.


Once done, click on the Next Question button in the top right corner of this panel. You may navigate back and forth freely between all questions. Once done with all questions, click on End Exam. Your work will be validated at the end and score shown. Good Luck!


Weight: 6

Name: nginx-pod
Image: nginx:alpine



kubectl run nginx-pod --image=nginx:alpinx


kubectl run --generator=run-pod/v1 nginx-pod --image=nginx:alpine



============================================================================================================
[2]
Deploy a messaging pod using the redis:alpine image with the labels set to tier=msg.


Weight: 8

Pod Name: messaging
Image: redis:alpine
Labels: tier=ms

cat <<EOF > q2-01.yaml
apiVersion: v1
kind: Pod
metadata:
  name: messaging
  labels:
    tier: ms
spec:
  containers:
  - name: nginx
    image: redis:alpine
    ports:
    - containerPort: 80
EOF


Use the command kubectl run --generator=run-pod/v1 messaging --image=redis:alpine -l tier=msg



============================================================================================================
[3]


kubectl create namespace apx-x9984574



============================================================================================================
[4]

Get the list of nodes in JSON format and store it in a file at /opt/outputs/nodes-z3444kd9.json

Weight: 7

Task completed


kubectl get nodes -o json > /opt/outputs/nodes-z3444kd9.json


============================================================================================================
[5]
Create a service messaging-service to expose the messaging application within the cluster on port 6379.


Use imperative commands

labels -> tier=ms

Weight: 12

Service: messaging-service
Port: 6379
Type: ClusterIp
Use the right labels

kubectl expose pod messaging --name messaging-service --labels tier=ms --port=6379 --target-port=80



============================================================================================================
[6]
Create a deployment named hr-web-app using the image kodekloud/webapp-color with 2 replicas
Weight: 11

Name: hr-web-app
Image: kodekloud/webapp-color
Replicas: 2


kubectl run hr-web-app --image=kodekloud/webapp-color --replicas=2


============================================================================================================
[7]
static pod -> 

https://kubernetes.io/docs/tasks/configure-pod-container/static-pod/#static-pod-creation


============================================================================================================
[] easy
============================================================================================================
[] easy
============================================================================================================
[10] easy
Expose the hr-web-app as service hr-web-app-service application on port 30082 on the nodes on the cluster


The web application listens on port 8080


Weight: 10

Name: hr-web-app-service
Type: NodePort
Endpoints: 2
Port: 8080
NodePort: 30082


============================================================================================================
[11] Use JSON PATH query to retrieve the osImages of all the nodes and store it in a file /opt/outputs/nodes_os_x43kj56.txt


The osImages are under the nodeInfo section under status of each node.


Weight: 6

Task Completed

kubectl get nodes -o jsonpath='{.items[*].status.nodeInfo.osImages}' #incorrect

kubectl get nodes -o jsonpath='{.items[*].status.nodeInfo.osImage}' > /opt/outputs/nodes_os_x43kj56.txt
============================================================================================================
[]
============================================================================================================
[12]
Create a Persistent Volume with the given specification.


Weight: 8

Volume Name: pv-analytics
Storage: 100Mi
Access modes: ReadWriteMany
Host Path: /pv/data-analytics


apiVersion: v1
kind: PersistentVolume
metadata:
  name: pv-analytics
spec:
  capacity:
    storage: 100Mi
  volumeMode: Filesystem
  accessModes:
    - ReadWriteMany
  hostPath:
      path: /pv/data-analytics


============================================================================================================
[]


