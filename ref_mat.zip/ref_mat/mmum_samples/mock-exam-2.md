[1] 
[]
[]
[]
[]
[]
[]
[]



============================================================================================================
[1]
Take a backup of the etcd cluster and save it to /tmp/etcd-backup.db


Weight: 10

Backup Completed

answer -> 

Run the command ETCDCTL_API=3 etcdctl --endpoints https://[127.0.0.1]:2379 --cacert /etc/kubernetes/pki/etcd/ca.crt --cert /etc/kubernetes/pki/etcd/healthcheck-client.crt --key=/etc/kubernetes/pki/etcd/healthcheck-client.key snapshot save /tmp/etcd-backup.db




============================================================================================================
[2]
Create a Pod called redis-storage with image: redis:alpine with a Volume of type emptyDir that lasts for the life of the Pod. Specs on the right.


Weight: 10

Pod named 'redis-storage' created
Pod 'redis-storage' uses Volume type of emptyDir
Pod 'redis-storage' uses volumeMount with mountPath = /data/redis

answer -> 

apiVersion: v1
kind: Pod
metadata:
  creationTimestamp: null
  labels:
    run: redis-storage
  name: redis-storage
spec:
  containers:
  - image: redis:alpine
    name: redis-storage
    volumeMounts:
    - mountPath: /data/redis
      name: temp-volume
  volumes:
  - name: temp-volume
    emptyDir: {}




============================================================================================================
[3]

Create a new pod called super-user-pod with image busybox:1.28. Allow the pod to be able to set system_time


The container should sleep for 4800 seconds


Weight: 8

Pod: super-user-pod
Container Image: busybox:1.28
SYS_TIME capabilities for the conatiner?


answer -> 

Add a securityContext Capabilities at container level


============================================================================================================
[4]
A pod definition file is created at /root/use-pv.yaml. Make use of this manifest file and mount the persistent volume called pv-1. Ensure the pod is running and the PV is bound.


mountPath: /data persistentVolumeClaim Name: my-pvc


Weight: 12

persistentVolume Claim configured correctly
pod using the correct mountPath
pod using the persistent volume claim?

answer -> 

Add a persistentVolumeClaim definition to pod definition file

============================================================================================================
[5]
Create a new deployment called nginx-deploy, with image nginx:1.16 and 1 replica. Record the version. Next upgrade the deployment to version 1.17 using rolling update. Make sure that the version upgrade is recorded in the resource annotation.


Weight: 15

Deployment : nginx-deploy. Image: nginx:1.16
Image: nginx:1.16
Task: Upgrade the version of the deployment to 1:17
Task: Record the changes for the image upgrade

answer -> 


Explore the --record option while creating the deployment. Use kubectl edit or kubectl set image to upgrade the version

============================================================================================================
[6]

Create a new user called john. Grant him access to the cluster. John should have permission to create, list, get, update and delete pods in the development namespace . The private key exists in the location: /root/john.key and csr at /root/john.csr


Weight: 15

CSR: john-developer Status:Approved
Role Name: developer, namespace: development, Resource: Pods
Access: User 'john' has appropriate permissions

answer -> 


Generate a certificateSigningRequest for John and get it approved. Create the correct RBAC configuration for the user.


https://kubernetes.io/docs/reference/access-authn-authz/rbac/



============================================================================================================
[7]

Create an nginx pod called nginx-resolver using image nginx, expose it internally with a service called nginx-resolver-service. Test that you are able to look up the service and pod names from within the cluster. Use the image: busybox:1.28 for dns lookup. Record results in /root/nginx.svc and /root/nginx.pod


Weight: 15

Pod: nginx-resolver created
Service DNS Resolution recorded correctly
Pod DNS resolution recorded correctl

answer -> 



============================================================================================================
[8]

Create a static pod on node01 called nginx-critical with image nginx. Create this pod on node01 and make sure that it is recreated/restarted automatically in case of a failure.


Use /etc/kubernetes/manifests as the Static Pod path for example.


Weight: 15

Kubelet Configured for Static Pods
Pod nginx-critical-node01 is Up and running

answer -> 

Add --pod-manifest-path to kubelet service on worker or staticPodPath in the kubelet config.yaml


============================================================================================================
[]
============================================================================================================
[]
============================================================================================================
[]
============================================================================================================
[]
============================================================================================================
[]
============================================================================================================
[]
============================================================================================================
[]
============================================================================================================
[]
============================================================================================================
[]
============================================================================================================
[]


