
###
NAMESPACE     NAME                                   READY   STATUS    RESTARTS   AGE
app-space     pod/default-backend-7f8776b5dc-l842n   1/1     Running   0          91s
app-space     pod/webapp-video-695b455597-w5sg8      1/1     Running   0          91s
app-space     pod/webapp-wear-d79845dbb-bsl54        1/1     Running   0          90s
kube-system   pod/coredns-5644d7b6d9-4qkhn           1/1     Running   0          2m23s
kube-system   pod/coredns-5644d7b6d9-h7dlr           1/1     Running   0          2m23s
kube-system   pod/etcd-master                        1/1     Running   0          88s
kube-system   pod/kube-apiserver-master              1/1     Running   0          76s
kube-system   pod/kube-controller-manager-master     1/1     Running   0          94s
kube-system   pod/kube-proxy-thx8f                   1/1     Running   0          2m4s
kube-system   pod/kube-proxy-x68bf                   1/1     Running   0          2m23s
kube-system   pod/kube-scheduler-master              1/1     Running   0          80s
kube-system   pod/weave-net-4gqkw                    2/2     Running   1          2m23s
kube-system   pod/weave-net-dnn98                    2/2     Running   0          2m4s

NAMESPACE     NAME                           TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)                  AGE
app-space     service/default-http-backend   ClusterIP   10.98.245.82     <none>        80/TCP                   91s
app-space     service/video-service          ClusterIP   10.104.149.35    <none>        8080/TCP                 91s
app-space     service/wear-service           ClusterIP   10.102.197.144   <none>        8080/TCP                 91s
default       service/kubernetes             ClusterIP   10.96.0.1        <none>        443/TCP                  2m30s
kube-system   service/kube-dns               ClusterIP   10.96.0.10       <none>        53/UDP,53/TCP,9153/TCP   2m29s

NAMESPACE     NAME                        DESIRED   CURRENT   READY   UP-TO-DATE   AVAILABLE   NODE SELECTOR                 AGE
kube-system   daemonset.apps/kube-proxy   2         2         2       2            2           beta.kubernetes.io/os=linux   2m29s
kube-system   daemonset.apps/weave-net    2         2         2       2            2           <none>                        2m28s

NAMESPACE     NAME                              READY   UP-TO-DATE   AVAILABLE   AGE
app-space     deployment.apps/default-backend   1/1     1            1           91s
app-space     deployment.apps/webapp-video      1/1     1            1           91s
app-space     deployment.apps/webapp-wear       1/1     1            1           92s
kube-system   deployment.apps/coredns           2/2     2            2           2m29s

NAMESPACE     NAME                                         DESIRED   CURRENT   READY   AGE
app-space     replicaset.apps/default-backend-7f8776b5dc   1         1         1       91s
app-space     replicaset.apps/webapp-video-695b455597      1         1         1       91s
app-space     replicaset.apps/webapp-wear-d79845dbb        1         1         1       92s
kube-system   replicaset.apps/coredns-5644d7b6d9           2         2         2       2m23s

###
kubectl create namespace ingress-space
###
kubectl create configmap nginx-configuration --namespace ingress-space
###
kubectl create serviceaccount ingress-serviceaccount --namespace ingress-space
###
kubectl get roles,rolebindings --namespace ingress-space
###
cat /var/answers/ingress-controller-answer-file.yaml
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ingress-controller
  namespace: ingress-space
spec:
  replicas: 1
  selector:
    matchLabels:
      name: nginx-ingress
  template:
    metadata:
      labels:
        name: nginx-ingress
    spec:
      serviceAccountName: ingress-serviceaccount
      containers:
        - name: nginx-ingress-controller
          image: quay.io/kubernetes-ingress-controller/nginx-ingress-controller:0.21.0
          args:
            - /nginx-ingress-controller
            - --configmap=$(POD_NAMESPACE)/nginx-configuration
            - --default-backend-service=app-space/default-http-backend
          env:
            - name: POD_NAME
              valueFrom:
                fieldRef:
                  fieldPath: metadata.name
            - name: POD_NAMESPACE
              valueFrom:
                fieldRef:
                  fieldPath: metadata.namespace
          ports:
            - name: http
              containerPort: 80
            - name: https
              containerPort: 443

kubectl apply -f /var/answers/ingress-controller-answer-file.yaml
deployment.apps/ingress-controller created
###
cat /var/answers/ingress-service.yaml
---
apiVersion: v1
kind: Service
metadata:
  name: ingress
  namespace: ingress-space
spec:
  type: NodePort
  ports:
  - port: 80
    targetPort: 80
    protocol: TCP
    nodePort: 30080
    name: http
  - port: 443
    targetPort: 443
    protocol: TCP
    name: https
  selector:
    name: nginx-ingressmaster
	
###
cat /var/answers/ingress-resource.yaml
---
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: ingress-wear-watch
  namespace: app-space
  annotations:
    nginx.ingress.kubernetes.io/rewrite-target: /
    nginx.ingress.kubernetes.io/ssl-redirect: "false"
spec:
  rules:
  - http:
      paths:
      - path: /wear
        backend:
          serviceName: wear-service
          servicePort: 8080
      - path: /watch
        backend:
          serviceName: video-service
          servicePort: 8080
###
###
###
###
###
###
###
