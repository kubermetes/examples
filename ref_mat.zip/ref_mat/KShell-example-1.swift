Preview Question 1
Use context:  kubectl config use-context k8s-c2-AC
The cluster admin asked you to  nd out the following information about etcd running on cluster2-master1:
Server private key location
Server certi cate expiration date
Is client certi cate authentication enabled
Write these information into  /opt/course/p1/etcd-info.txt
Finally you're asked to save an etcd snapshot at  /etc/etcd-snapshot.db  on cluster2-master1 and display its status.


Find out etcd information
Let's check the nodes:

➜ k get node
NAME               STATUS   ROLES    AGE    VERSION
cluster2-master1   Ready    master   140m   v1.17.3
cluster2-worker1   Ready    <none>   136m   v1.17.3
➜ ssh root@cluster2-master1

First we check how etcd is setup in this cluster:


➜ root@cluster2-master1:~# kubectl -n kube-system get pod
NAME                                       READY   STATUS    RESTARTS   AGE
coredns-5644d7b6d9-2mf7n                   1/1     Running   0          9h
coredns-5644d7b6d9-8jsd2                   1/1     Running   0          9h
etcd-cluster2-master1                      1/1     Running   0          9h
kube-apiserver-cluster2-master1            1/1     Running   0          77m
kube-controller-manager-cluster2-master1   1/1     Running   0          9h
kube-proxy-fn6hw                           1/1     Running   0          8h
kube-proxy-m52sx                           1/1     Running   0          7h52m
kube-scheduler-cluster2-master1            1/1     Running   0          8h
weave-net-9n5xt                            2/2     Running   0          9h
weave-net-ghxhs                            2/2     Running   1          9h


We see its running as a pod, more speci c a static pod. So we check for the default kubelet directory for static manifests:


➜ root@cluster2-master1:~# find /etc/kubernetes/manifests/
/etc/kubernetes/manifests/
/etc/kubernetes/manifests/kube-controller-manager.yaml
/etc/kubernetes/manifests/kube-apiserver.yaml
/etc/kubernetes/manifests/etcd.yaml
/etc/kubernetes/manifests/kube-scheduler.yaml
➜ root@cluster2-master1:~# vim /etc/kubernetes/manifests/etcd.yaml


So we look at the yaml and the parameters with which etcd is started:
alias k=kubectl


# /etc/kubernetes/manifests/etcd.yaml
apiVersion: v1
kind: Pod
metadata:
  creationTimestamp: null
  labels:
    component: etcd
    tier: control-plane
  name: etcd
  namespace: kube-system
spec:
  containers:
  - command:
    - etcd
    - --advertise-client-urls=https://192.168.102.11:2379
    - --cert-file=/etc/kubernetes/pki/etcd/server.crt              # server certificate
    - --client-cert-auth=true                                      # enabled
    - --data-dir=/var/lib/etcd
    - --initial-advertise-peer-urls=https://192.168.102.11:2380
    - --initial-cluster=cluster2-master1=https://192.168.102.11:2380
    - --key-file=/etc/kubernetes/pki/etcd/server.key               # server private key
    - --listen-client-urls=https://127.0.0.1:2379,https://192.168.102.11:2379
    - --listen-metrics-urls=http://127.0.0.1:2381
    - --listen-peer-urls=https://192.168.102.11:2380
    - --name=cluster2-master1
    - --peer-cert-file=/etc/kubernetes/pki/etcd/peer.crt
    - --peer-client-cert-auth=true
    - --peer-key-file=/etc/kubernetes/pki/etcd/peer.key
    - --peer-trusted-ca-file=/etc/kubernetes/pki/etcd/ca.crt
    - --snapshot-count=10000
    - --trusted-ca-file=/etc/kubernetes/pki/etcd/ca.crt
 
 
 We see that client authentication is enabled and also the requested path to the server private key, now let's  nd out the expiration
of the server certi cate:
 
 ➜ root@cluster2-master1:~# openssl x509  -noout -text -in /etc/kubernetes/pki/etcd/server.crt | grep Validity 
-A2
        Validity
            Not Before: Feb 21 11:08:43 2020 GMT
            Not After : Feb 20 11:08:43 2021 GMT
 
 There we have it. Let's write the information into the requested  le:
 
 # /opt/course/p1/etcd-info.txt
Server private key location: /etc/kubernetes/pki/etcd/server.key
Server certificate expiration date: Feb 20 11:08:43 2021 GMT
Is client certificate authentication enabled: yes
 
 
Create etcd snapshot

First we try:
 
ETCDCTL_API=3 etcdctl snapshot save /etc/etcd-snapshot.db

We get the endpoint also from the yaml. But we need to specify more parameters, all of which we can  nd the yaml declaration
above:

 
ETCDCTL_API=3 etcdctl snapshot save /etc/etcd-snapshot.db \
--cacert /etc/kubernetes/pki/etcd/ca.crt \
--cert /etc/kubernetes/pki/etcd/server.crt \
--key /etc/kubernetes/pki/etcd/server.key


This worked. Now we can output the status of the backup  le:


➜ root@cluster2-master1:~# ETCDCTL_API=3 etcdctl snapshot status /etc/etcd-snapshot.db
73e9dc3d, 46960, 741, 1.8 MB


The status shows:
Hash: 73e9dc3d
Revision: 46960
Total Keys: 741
Total Size: 1.8 MB

===========================================================================================================

 
Preview Question 2
Use context:  kubectl config use-context k8s-c1-H4/2/2020 Killer Shell - CKA CKAD Simulator
https://killer.sh/course/preview/e84d0e31-4fff-4c42-8afd-be1bdbc0d994 3/7
 
You're asked to con rm that kube-proxy is running correctly on all nodes. For this perform the following in namespace  project-
hamster :
Create a new pod named  p2-pod  with two containers, one of image  nginx:1.17-alpine  and one of image  busybox:1.31 . Make
sure the busybox container keeps running for some time.
Create a new service named  p2-service  which exposes that pod internally in the cluster on port 3000->80.
Con rm that kube-proxy is running on all nodes cluster1-master1, cluster1-worker1 and cluster1-worker2 and that it's using
iptables.
Write the iptables rules of all nodes belonging the created service  p2-service  into  le  /opt/course/p2/iptables.txt .
Finally delete the service and con rm that the iptables rules are gone from all nodes.



Answer:
Create the pod
First we create the pod:

k run p2-pod --image=nginx:1.17-alpine --restart=Never -o yaml --dry-run > p2.yaml
vim p2.yaml


Next we add the requested second container:


# p2.yaml
apiVersion: v1
kind: Pod
metadata:
  creationTimestamp: null
  labels:
    run: p2-pod
  name: p2-pod
  namespace: project-hamster             # add
spec:
  containers:
  - image: nginx:1.17-alpine
    name: p2-pod
  - image: busybox:1.31                  # add
    name: c2                             # add
    command: ["sh", "-c", "sleep 1d"]    # add
    resources: {}
  dnsPolicy: ClusterFirst
  restartPolicy: Never
status: {}


And we create the pod:

k -f p2.yaml create


Create the service

Next we create the service:


k -n project-hamster expose pod p2-pod --name p2-service --port 3000 --target-port 80

This will create a yaml like:

apiVersion: v1
kind: Service
metadata:
  labels:
    run: p2-pod
  name: p2-service
  namespace: project-hamster
spec:
  ports:
  - port: 3000
    protocol: TCP
    targetPort: 80
  selector:
    run: p2-pod



We should con rm pods and services are connected, hence the service should have endpoints.


k -n project-hamster get pod,svc,ep



Con rm kube-proxy is running and is using iptables
First we get nodes in the cluster:


➜ k get node
NAME               STATUS   ROLES    AGE    VERSION
cluster1-master1   Ready    master   155m   v1.17.3
cluster1-worker1   Ready    <none>   152m   v1.17.3
cluster1-worker2   Ready    <none>   149m   v1.17.3


The idea here is to log into every node,  nd the kube-proxy docker container and check its logs:


➜ ssh root@cluster1-master1
➜ root@cluster1-master1$ docker ps | grep kube-proxy
2aca9735e6ae   ...  "/usr/local/bin/kube…"  ...  k8s_kube-proxy_kube-proxy-...
fd283576728e   ...  "/pause"                ...  k8s_POD_kube-proxy-n96fl_k...
➜ root@cluster1-master1~# docker logs 2aca9735e6ae
...
I1207 18:04:39.720910       1 server_others.go:149] Using iptables Proxier.



This should be repeated on every node and result in the same output  Using iptables Proxier .


Check kube-proxy is creating iptables rules

Now we check the iptables rules on every node, and write those into the requested  le


		➜ ssh root@cluster1-master1 iptables-save | grep p2-service
		-A KUBE-SERVICES ! -s 10.244.0.0/16 -d 10.109.140.124/32 -p tcp -m comment --comment "project-hamster/p2-
		service: cluster IP" -m tcp --dport 3000 -j KUBE-MARK-MASQ
		-A KUBE-SERVICES -d 10.109.140.124/32 -p tcp -m comment --comment "project-hamster/p2-service: cluster IP" -m 
		tcp --dport 3000 -j KUBE-SVC-2A6FNMCK6FDH7PJH
		➜ ssh root@cluster1-worker1 iptables-save | grep p2-service
		-A KUBE-SERVICES ! -s 10.244.0.0/16 -d 10.109.140.124/32 -p tcp -m comment --comment "project-hamster/p2-
		service: cluster IP" -m tcp --dport 3000 -j KUBE-MARK-MASQ
		-A KUBE-SERVICES -d 10.109.140.124/32 -p tcp -m comment --comment "project-hamster/p2-service: cluster IP" -m 
		tcp --dport 3000 -j KUBE-SVC-2A6FNMCK6FDH7PJH
		➜ ssh root@cluster1-worker2 iptables-save | grep p2-service
		-A KUBE-SERVICES ! -s 10.244.0.0/16 -d 10.109.140.124/32 -p tcp -m comment --comment "project-hamster/p2-
		service: cluster IP" -m tcp --dport 3000 -j KUBE-MARK-MASQ
		-A KUBE-SERVICES -d 10.109.140.124/32 -p tcp -m comment --comment "project-hamster/p2-service: cluster IP" -m 
		tcp --dport 3000 -j KUBE-SVC-2A6FNMCK6FDH7PJH


Great. Now let's write these logs into the requested  le:


	➜ ssh root@cluster1-master1 iptables-save | grep p2-service >> /opt/course/p2/iptables.txt
	➜ ssh root@cluster1-worker1 iptables-save | grep p2-service >> /opt/course/p2/iptables.txt
	➜ ssh root@cluster1-worker2 iptables-save | grep p2-service >> /opt/course/p2/iptables.txt


Delete the service and con rm iptables rules are gone
Delete the service:


k -n project-hamster delete svc p2-service


And con rm the iptables rules are gone:


➜ ssh root@cluster1-master1 iptables-save | grep p2-service
➜ ssh root@cluster1-worker1 iptables-save | grep p2-service
➜ ssh root@cluster1-worker2 iptables-save | grep p2-service



Done.
Kubernetes services are implemented using iptables rules (with default con g) on all nodes. Every time a service has been altered,
created, deleted or endpoints of a service have changed, the kube-apiserver contacts every node's kube-proxy to update the iptables
rules according to the current state.


===========================================================================================================


Preview Question 3

Use context:  kubectl config use-context k8s-c1-H

There should be two schedulers on cluster1-master1, but only one is is reported to be running. Write all scheduler pod names and
their status into  /opt/course/p3/schedulers.txt .
There is an existing pod named  special  in namespace  default  which should be scheduled by the second scheduler, but it's in a
pending state.
Fix the second scheduler. Con rm it's working by checking that pod  special  is scheduled on a node and running.

Answer:
Write the scheduler info into  le:

k -n kube-system get pod --show-labels # find labels
k -n kube-system get pod -l component=kube-scheduler > /opt/course/p3/schedulers.txt


The  le could look like:

# /opt/course/p3/schedulers.txt
NAME                                      READY   STATUS    RESTARTS   AGE
kube-scheduler-cluster1-master1           1/1     Running   0          17m
kube-scheduler-special-cluster1-master1   0/1     Error     2          23s


Check that pod:


➜ k get pod special -o wide
NAME      READY   STATUS    ...  NODE     NOMINATED
special   0/1     Pending   ...  <none>   <none>  
➜ k get pod special -o jsonpath="{.spec.schedulerName}{'\n'}"
kube-scheduler-special-cluster1-master1


Seems it has no node assigned because of the scheduler not working.

Fix the Scheduler

First we get the available schedulers:


➜ k -n kube-system get pod | grep scheduler                                                                 
kube-scheduler-cluster1-master1            1/1     Running            0          26m
kube-scheduler-special-cluster1-master1    0/1     CrashLoopBackOff   1          11s

It seems both are running as static pods due to their name su xes. First we check the logs:

	➜ k -n kube-system logs kube-scheduler-special-cluster1-master1
	Error: unknown flag: --this-is-no-parameter
	Usage:
	  kube-scheduler [flags]
	...

Well, it seems there is a unknown parameter set. So we connect into the master node, and check the manifests  le:

➜ ssh root@cluster1-master1
➜ root@cluster1-master1:~# vim /etc/kubernetes/manifests/kube-scheduler-special.yaml


The kubelet could also have a di erent manifests directory speci ed via parameter  --pod-manifest-path  which you could  nd out
via  ps aux | grep kubelet  and checking the kubelet systemd con g. But in our case it's the default one.
Let's check the schedulers yaml:


# /etc/kubernetes/manifests/kube-scheduler-special.yaml
apiVersion: v1
kind: Pod
metadata:
  creationTimestamp: null
  name: kube-scheduler-special
  namespace: kube-system
spec:
  containers:
  - command:
    - kube-scheduler
    - --authentication-kubeconfig=/etc/kubernetes/scheduler.conf
    - --authorization-kubeconfig=/etc/kubernetes/scheduler.conf
    - --bind-address=127.0.0.1
    - --port=7776
    - --secure-port=7777
    - --kubeconfig=/etc/kubernetes/kube-scheduler.conf
    - --leader-elect=false
	- --scheduler-name=kube-scheduler-special
	    #- --this-is-no-parameter=what-the-hell                 # remove this obvious error
	    image: k8s.gcr.io/kube-scheduler:v1.17.3



Changes on static pods are recognised automatically by the kubelet, so we wait shortly and check again (you might need to give it a
few seconds):

➜ root@cluster1-master1:~# kubectl -n kube-system get pod | grep scheduler
kube-scheduler-cluster1-master1            1/1     Running            0          90m
kube-scheduler-special-cluster1-master1    0/1     CrashLoopBackOff   1          7s


Still an error, let's check the logs again:


➜ root@cluster1-master1:~# kubectl -n kube-system logs kube-scheduler-special-cluster1-master1
I1207 20:40:30.385545       1 serving.go:319] Generated self-signed cert in-memory
stat /etc/kubernetes/kube-scheduler.conf: no such file or directory


Well, it seems there is a  le missing or a wrong path speci ed for that scheduler. So we check the manifests  le again:


apiVersion: v1
kind: Pod
metadata:
  creationTimestamp: null
  name: kube-scheduler-special
  namespace: kube-system
spec:
  containers:
  - command:
    - kube-scheduler
    - --authentication-kubeconfig=/etc/kubernetes/scheduler.conf
    - --authorization-kubeconfig=/etc/kubernetes/scheduler.conf
    - --bind-address=127.0.0.1
    - --port=7776
    - --secure-port=7777
    #- --kubeconfig=/etc/kubernetes/kube-scheduler.conf          # wrong path
    - --kubeconfig=/etc/kubernetes/scheduler.conf                # correct path
    - --leader-elect=false
    - --scheduler-name=kube-scheduler-special         
    #- --this-is-no-parameter=what-the-hell
    image: k8s.gcr.io/kube-scheduler:v1.17.3
...


Save and check the logs again:


➜ root@cluster1-master1:~# kubectl -n kube-system logs kube-scheduler-special-cluster1-master1
I1207 19:48:32.211659       1 serving.go:319] Generated self-signed cert in-memory
I1207 19:48:32.739284       1 server.go:148] Version: v1.17.3
I1207 19:48:32.739527       1 defaults.go:91] TaintNodesByCondition is enabled, PodToleratesNodeTaints 
predicate is mandatory
W1207 19:48:32.758572       1 authorization.go:47] Authorization is disabled
W1207 19:48:32.758702       1 authentication.go:79] Authentication is disabled
I1207 19:48:32.759120       1 deprecated_insecure_serving.go:51] Serving healthz insecurely on [::]:7776
I1207 19:48:32.759730       1 secure_serving.go:123] Serving securely on 127.0.0.1:7777
I1207 19:48:32.863430       1 leaderelection.go:241] attempting to acquire leader lease  kube-system/kube-
scheduler...


Looking better, and the status:


➜ root@cluster1-master1:~# kubectl -n kube-system get pod | grep scheduler
kube-scheduler-cluster1-master1            1/1     Running   0          20m
kube-scheduler-special-cluster1-master1    1/1     Running   0          114s


Well, I call this beautifully  xed!


Check the pod again
Finally, is the pod running and scheduled on a node?



➜ k get pod special -o wide
NAME      READY   STATUS    ...   NODE               NOMINATED NODE
special   1/1     Running   ...   cluster1-worker2   <none>     


Yes, we did it!
If you have to troubleshoot Kubernetes services in the CKA exam you should  rst check the logs. Then check its conFIg and
parameters for obvious miscon gurations. A good starting point is checking if all paths (to con g  les or certi cates) are correct.

























 
 